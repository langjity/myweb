#-*- coding: utf-8 -*-
import scrapy.cmdline as cmd
cmd.execute('scrapy crawl LagouSpider'.split())
