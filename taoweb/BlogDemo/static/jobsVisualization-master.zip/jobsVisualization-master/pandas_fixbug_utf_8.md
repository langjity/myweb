# 处理pandas utf-8的问题
参考[编码相关的笔记](http://blog.just4fun.site/decode-and-encode-note.html) 中的策略部分成果解决
