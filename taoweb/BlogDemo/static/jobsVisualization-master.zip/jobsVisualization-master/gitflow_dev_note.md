# 常用git工具
*  gitup:用于管理commit
*  tig:gui
*  [git-flow 备忘清单](http://danielkummer.github.io/git-flow-cheatsheet/index.zh_CN.html)

### gitflow
*  git flow init
*  git flow feature start pandas_fix_utf_8
*  git flow feature finish pandas_fix_utf_8
*  git flow release start release-20160629 develop
*  git flow release list
*  git flow release publish release-20160629
*  git flow release finish release-20160629  //合并到master和develop中
